package com.attendance.service;

public interface LoginService {
	
	public String login(String account,String password);
}
