package com.attendance.dao;

public interface LoginDao {
	
	public String login(String account,String password);
	
}
